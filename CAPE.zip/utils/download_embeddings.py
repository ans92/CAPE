import fasttext.util
fasttext.util.download_model('en', if_exists='ignore')  # English

